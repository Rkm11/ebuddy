<?php
namespace App\PiplModules\Category\Models;

use Illuminate\Database\Eloquent\Model;

class CategoryTranslation extends Model 
{

	protected $fillable = ['name'];
	
}