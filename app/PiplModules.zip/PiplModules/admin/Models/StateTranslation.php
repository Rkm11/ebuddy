<?php
namespace App\PiplModules\Admin\Models;

use Illuminate\Database\Eloquent\Model as Eloquent ;

class StateTranslation extends Eloquent
{

    protected $fillable = array('name');

}