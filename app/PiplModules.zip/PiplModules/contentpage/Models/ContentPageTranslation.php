<?php
namespace App\PiplModules\contentpage\Models;

use Illuminate\Database\Eloquent\Model as Eloquent ;

class ContentPageTranslation extends Eloquent
{

    protected $fillable = array('name');

}