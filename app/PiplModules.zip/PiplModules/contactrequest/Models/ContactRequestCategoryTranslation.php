<?php
namespace App\PiplModules\contactrequest\Models;

use Illuminate\Database\Eloquent\Model;

class ContactRequestCategoryTranslation extends Model 
{

	protected $fillable = ['name'];
	
}