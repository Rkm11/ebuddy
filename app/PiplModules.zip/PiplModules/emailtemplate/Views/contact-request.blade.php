<p>Dear Admin, A user {{$USER_NAME}} has submit an contact request. Please check admin Panel and manage accordingly Below are the contact request details:- Name: {{$USER_NAME}} Email: {{$USER_EMAIL}} Phone: {{$USER_PHONE}} Category: {{$CATEGORY}} SUBJECT: {{$SUBJECT}} Message: {{$MESSAGE}} REFERENCE No: {{$REFERENCE}} Thanks,<br />
PIPL Lib Team</p>
