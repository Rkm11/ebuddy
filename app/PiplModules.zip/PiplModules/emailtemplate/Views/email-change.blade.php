<html><body>Hello {{$FIRST_NAME}} {{$LAST_NAME}}, Your email has been changed successfully. Please verify your email by clicking on the link provided belowground
        <br><br><a href="{{$VERIFICATION_LINK}}">{{$VERIFICATION_LINK}}</a><br></br>
 Thanks,
 Code Library Team