<p>Hello {{$USER_NAME}}, Please see below link to reset your password.<br />
<br />
<a href="{{$RESET_LINK}}">{{$RESET_LINK}}</a><br />
<br />
Thanks,<br />
PIPL Lib Team</p>
