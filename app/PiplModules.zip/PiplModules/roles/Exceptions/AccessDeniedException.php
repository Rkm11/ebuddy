<?php

namespace App\PiplModules\roles\Exceptions;

use Exception;

class AccessDeniedException extends Exception
{
    //
}
