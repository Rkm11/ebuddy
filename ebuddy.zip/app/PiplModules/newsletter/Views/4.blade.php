<p>Hey {{$email}},</p>

<p>We have now launched new SAAS plan for iDesigniBuy. <a href="http://idesignibuy.com">Click here </a>to know more....</p>

<p>&nbsp;</p>

<p>Thanks,</p>

<p>Laravel PIPL Lib</p>
