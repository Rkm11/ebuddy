<html>
    <body>Hello {{$FIRST_NAME}} {{$LAST_NAME}},
        <br>
         Your registration has been completed successfully!
       
         You could also use your account with your email and random generated password
          
         Email: {{$EMAIL}}
         Password: {{$PASSWORD}}
          
        Thanks,<br>PIPL Lib Team
    </body>
</html>