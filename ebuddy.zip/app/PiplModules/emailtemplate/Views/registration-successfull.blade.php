<html><body>Hello {{$FIRST_NAME}} {{$LAST_NAME}},
        <br>
        Your registration has been completed successfully!
       
        Please activate your account by clicking on the link provided below
        
        <a href="{{$VERIFICATION_LINK}}">Click Here</a>
  
          
        Thanks,<br>PIPL Lib Team