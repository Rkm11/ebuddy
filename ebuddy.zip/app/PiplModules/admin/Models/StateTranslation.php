<?php
namespace App\PiplModules\admin\Models;

use Illuminate\Database\Eloquent\Model as Eloquent ;

class StateTranslation extends Eloquent
{

    protected $fillable = array('name');

}