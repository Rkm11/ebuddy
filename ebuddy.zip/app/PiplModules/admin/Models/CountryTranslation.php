<?php
namespace App\PiplModules\admin\Models;

use Illuminate\Database\Eloquent\Model as Eloquent ;

class CountryTranslation extends Eloquent
{

    protected $fillable = array('name');

}