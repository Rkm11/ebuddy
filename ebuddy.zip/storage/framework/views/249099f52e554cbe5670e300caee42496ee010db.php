<html><body>Hello <?php echo e($FIRST_NAME); ?> <?php echo e($LAST_NAME); ?>,
        <br>
        Your registration has been completed successfully!
       
        Please activate your account by clicking on the link provided below
        
        <a href="<?php echo e($VERIFICATION_LINK); ?>">Click Here</a>
  
          
        Thanks,<br>PIPL Lib Team