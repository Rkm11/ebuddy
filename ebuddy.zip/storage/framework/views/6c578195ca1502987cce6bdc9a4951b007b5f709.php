 <?php $__env->startSection('meta'); ?>
    <title>User Registration</title>
 <?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Normal User Registration</div>
                <div class="panel-body">
                    <form class="form-horizontal" name="register_normal" id="register_normal" role="form" method="POST" action="<?php echo e(url('/register')); ?>">
                        <?php echo csrf_field(); ?>

                        <input type='hidden' name='user_type' id='user_type' value='3'>
                        <div class="form-group<?php echo e($errors->has('first_name') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">First Name</label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="first_name" value="<?php echo e(old('first_name')); ?>">
                                 <?php if($errors->has('first_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('first_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                         <div class="form-group<?php echo e($errors->has('last_name') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">Last Name</label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="last_name" value="<?php echo e(old('last_name')); ?>">
                                 <?php if($errors->has('last_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('last_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">Email</label>

                            <div class="col-md-6">
                                <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>">

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input type="password" id="password" class="form-control" name="password">

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">Confirm Password</label>

                            <div class="col-md-6">
                                <input type="password" class="form-control" name="password_confirmation">

                                <?php if($errors->has('password_confirmation')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('suburb') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">Suburb</label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="suburb" value="<?php echo e(old('suburb')); ?>">
                                 <?php if($errors->has('suburb')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('suburb')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('post_code') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">Post Code</label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="zipcode" value="<?php echo e(old('zipcode')); ?>">
                                 <?php if($errors->has('zipcode')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('zipcode')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('countrycode') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">Country Code</label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="countrycode" value="<?php echo e(old('countrycode')); ?>">
                                 <?php if($errors->has('countrycode')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('countrycode')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                       
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary" id="btn_register">
                                    <i class="fa fa-btn fa-user"></i>Register
                                </button>
                                <img id="btn_loader" style="display:none;" src="<?php echo e(url('public/media/front/images/loader.gif')); ?>">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>