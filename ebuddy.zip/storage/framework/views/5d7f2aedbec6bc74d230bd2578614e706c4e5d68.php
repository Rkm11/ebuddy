<?php $__env->startSection('meta'); ?>
    <title>User Profile</title>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    User Profile
                </div>
               <?php if(session('password-update-success')): ?>
               <div class="alert alert-success">
                <?php echo e(session('password-update-success')); ?>

            	</div>
                <?php endif; ?>
               <?php if(session('profile-updated')): ?>
               <div class="alert alert-success">
                <?php echo e(session('profile-updated')); ?>

            	</div>
                <?php endif; ?>
                
                <div class="panel-body">
                  
                        <div class="form-group">
                            <label class="col-md-4 control-label">First Name</label>
                            <div class="col-md-6">
                                <label class="col-md-4 control-label"><?php echo e($user_info->userInformation->first_name); ?></label>
                            </div>
                        </div>
                         <div class="form-group">
                            <label class="col-md-4 control-label">Last Name</label>
                            <div class="col-md-6">
                                 <label class="col-md-4 control-label"><?php echo e($user_info->userInformation->last_name); ?></label>
                              
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-4 control-label">Email</label>

                           <div class="col-md-6">
                                 <label class="col-md-4 control-label"><?php echo e($user_info->email); ?></label>
                              
                            </div>
                        </div>
                      
                        
                        <?php if(isset($user_info->userAddress->suburb)): ?>                       
                        <div class="form-group">
                            <label class="col-md-4 control-label">Suburb</label>
                            <div class="col-md-6">
                                 <label class="col-md-4 control-label"><?php echo e($user_info->userAddress->suburb); ?></label>
                              
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if(isset($user_info->userAddress->zipcode)): ?>                       
                        <div class="form-group<?php echo e($errors->has('zipcode') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">Zip Code</label>
                            <div class="col-md-6">
                                 <label class="col-md-4 control-label"><?php echo e($user_info->userAddress->zipcode); ?></label>
                              
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        
                    
                     </div>
                  <div class="row">
                         
                        <div class="col-md-3 top-margin">
                            <a href='<?php echo e(url('update-profile')); ?>' class="btn btn-primary pull-right">
                                        <i class="fa fa-btn fa-user"></i>Edit Profile
                            </a>
                        </div>   
                       
                       <div class="col-md-3 top-margin">
                         <a href='<?php echo e(url('change-email')); ?>' class="btn btn-primary pull-right">
                                    <i class="fa fa-btn fa-envelope"></i>Change Email
                        </a>
                        </div>  
                   
                       <div class="col-md-3 top-margin">     
                            <a href='<?php echo e(url('change-password')); ?>' class="btn btn-primary pull-right">
                                       <i class="fa fa-btn fa-lock"></i>Change Password
                           </a>
                        </div>
                     </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>