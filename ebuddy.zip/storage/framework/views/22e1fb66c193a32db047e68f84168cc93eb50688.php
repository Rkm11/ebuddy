<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<?php if($user_details->user_type==3): ?>
<?php echo $__env->make('includes.student-topbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php elseif($user_details->user_type==2): ?>
<?php echo $__env->make('includes.institute-topbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>)
<?php endif; ?>

<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>
