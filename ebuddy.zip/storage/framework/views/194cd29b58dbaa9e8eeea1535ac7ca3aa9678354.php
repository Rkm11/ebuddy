<?php $__env->startSection('meta'); ?>
<title><?php echo e($page_information->page_title); ?></title>
<meta name="keywords" content="<?php echo e($page_information->page_meta_keywords); ?>" />
<meta name="description" content="<?php echo e($page_information->page_meta_descriptions); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<section class="container">

<h1><?php echo e($page_information->page_title); ?></h1>

<div>
<?php echo $page_information->page_content; ?>

</div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make(config("piplmodules.front-view-layout-location"), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>